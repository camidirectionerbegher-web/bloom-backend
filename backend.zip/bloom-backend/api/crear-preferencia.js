// ═══════════════════════════════════════════════════════════════
//  BLOOM — Backend Mercado Pago (Vercel Serverless Function)
//  Endpoint: POST /api/crear-preferencia
// ═══════════════════════════════════════════════════════════════

export default async function handler(req, res) {
  // ── CORS: permitir llamadas desde tu tienda ──────────────────
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  // Pre-flight OPTIONS
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST")   return res.status(405).json({ error: "Método no permitido" });

  const ACCESS_TOKEN = process.env.MP_ACCESS_TOKEN;
  if (!ACCESS_TOKEN) {
    return res.status(500).json({ error: "MP_ACCESS_TOKEN no configurado en variables de entorno" });
  }

  try {
    const { items, payer, back_urls, external_reference } = req.body;

    // Validar que haya ítems
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "No hay ítems en el pedido" });
    }

    // Construir la preferencia para MP
    const preference = {
      items: items.map(item => ({
        id:          String(item.id || "prod"),
        title:       String(item.title || "Producto BLOOM"),
        quantity:    Number(item.quantity) || 1,
        currency_id: "ARS",
        unit_price:  Number(item.unit_price) || 0,
      })),
      payer: {
        email:   payer?.email   || "",
        name:    payer?.name    || "",
        surname: payer?.surname || "",
      },
      back_urls: {
        success: back_urls?.success || "https://tutienda.com",
        failure: back_urls?.failure || "https://tutienda.com",
        pending: back_urls?.pending || "https://tutienda.com",
      },
      auto_return:        "approved",
      external_reference: external_reference || ("BL-" + Date.now()),
      statement_descriptor: "BLOOM Store",
      // Cuotas sin interés (opcional — configurá en tu cuenta MP)
      payment_methods: {
        excluded_payment_types: [],
        installments: 12,
      },
    };

    // Llamar a la API de Mercado Pago
    const mpRes = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method:  "POST",
      headers: {
        "Content-Type":  "application/json",
        "Authorization": `Bearer ${ACCESS_TOKEN}`,
      },
      body: JSON.stringify(preference),
    });

    const data = await mpRes.json();

    if (!mpRes.ok) {
      console.error("MP API error:", data);
      return res.status(mpRes.status).json({ error: data.message || "Error de Mercado Pago", detail: data });
    }

    // Devolver al frontend la URL de pago y el ID
    return res.status(200).json({
      id:                  data.id,
      init_point:          data.init_point,          // producción
      sandbox_init_point:  data.sandbox_init_point,  // pruebas
    });

  } catch (err) {
    console.error("Error interno:", err);
    return res.status(500).json({ error: "Error interno del servidor", detail: err.message });
  }
}
